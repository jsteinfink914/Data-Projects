# -*- coding: utf-8 -*-
"""
Created on Wed Mar 30 17:51:55 2022

@author: jstei
"""


import plotly.graph_objs as go
import numpy as np

from datetime import datetime
import pandas as pd
import seaborn as sns
import plotly.express as px
from itertools import product
import matplotlib.pyplot as plt
from plotly.subplots import make_subplots
import plotly.figure_factory as ff


# =============================================================================
# HeatMap
# =============================================================================
sns.set_theme(style="ticks")

data = pd.read_csv('TopSongs.csv')
data2=data.drop(['title','top genre','year','artist'],axis=1)

ax=sns.heatmap(data2.corr(),cmap="YlGnBu", annot=True)
plt.title('Attribute Correlations',fontsize=20)
plt.xticks(fontsize=15,rotation=45)
plt.yticks(fontsize=15,rotation=45)



corr = data2.corr()
np_corr = corr.to_numpy().round(3)

fig5 = ff.create_annotated_heatmap(z=np_corr, 
                                  x=data2.columns.tolist(),
                                  y=data2.columns.tolist(),
                                  colorscale=px.colors.diverging.RdYlBu,
                                  #hoverinfo="none", #Shows hoverinfo for null values
                                  showscale=True, ygap=1, xgap=1
                                 )

fig5.update_xaxes(side="bottom")

fig5.update_layout(
    title_text='Heatmap', 
    title_x=0.5, 
    width=1000, 
    height=1000,
    xaxis_showgrid=False,
    yaxis_showgrid=False,
    xaxis_zeroline=False,
    yaxis_zeroline=False,
    yaxis_autorange='reversed',
    template='plotly_white'
)
fig5.write_html('test5.html')




# =============================================================================
# Working Trendline With Dropdown
# =============================================================================


grouped_data=data.groupby(by=['top genre','year']).mean().reset_index()

date=grouped_data['year'].unique()
date.sort()

attributes=['energy','danceability','liveliness','valence','acousticness','speechiness','popularity']


fig = go.Figure()

genre_list=['boy band','edm','hip hop','house','pop','rap']

for genre in genre_list:
    for attribute in attributes:
        fig.add_trace(
            go.Scatter(
                x = grouped_data['year'][grouped_data['top genre']==genre],
                y = grouped_data[attribute][grouped_data['top genre']==genre],
                name = attribute, visible = True
            )
        )
    
buttons = []

all_combinations=product(genre_list,attributes)
all_combinations=[i for i in all_combinations]

for i, genre in enumerate(genre_list):
    args = [False] * len(all_combinations)
    args[i*len(attributes):len(attributes)*(i+1)]=[True]*len(attributes)
    while len(args)<len(all_combinations):
        args.append(False)
    print(args)

    
    button = dict(label = genre,
                  method = "update",
                  args=[{"visible": args}])
    
    buttons.append(button)
    
fig.update_layout(
    updatemenus=[dict(
                    active=0,
                    type="dropdown",
                    buttons=buttons,
                    x = 0,
                    y = 1.1,
                    xanchor = 'left',
                    yanchor = 'bottom'
                )], 
    autosize=True,
    title=dict(text='Attribute Trends by Genre',
               x=.5),
    xaxis=dict(title='Year'),
    yaxis=dict(title='Attribute Mean'))



fig.write_html('test.html')

# =============================================================================
# Working Bar Chart with dropdown
# =============================================================================


##Second View
fig2 = go.Figure()

genre_list=['boy band','edm','hip hop','house','pop','rap']


for genre in genre_list:
    fig2.add_trace(
        go.Bar(
            x = data[data['top genre']==genre]['artist'].value_counts().index,
            y = list(data[data['top genre']==genre]['artist'].value_counts()),
            name = genre, visible = True
        )
    )
    
buttons = []


for i, genre in enumerate(genre_list):
    args = [False] * len(genre_list)
    args[i] = True
    print(args)
    
    button = dict(label = genre,
                  method = "update",
                  args=[{"visible": args}])
    
    buttons.append(button)
    
fig2.update_layout(
    updatemenus=[dict(
                    active=0,
                    type="dropdown",
                    buttons=buttons,
                    x = 0,
                    y = 1.1,
                    xanchor = 'left',
                    yanchor = 'bottom'
                )], 
    autosize=True,
    title=dict(text='Artists with the most Top Songs (2010-2019)',
               x=.5),
    xaxis=dict(title='Artistr'),
    yaxis=dict(title='Number of Songs'))



fig2.write_html('test2.html')

# =============================================================================
# Attempt at Linked View
# =============================================================================

fig3 = make_subplots(rows=2, cols=1,
                shared_xaxes=False,
                vertical_spacing=0.02)

for genre in genre_list:
    for attribute in attributes:
            trace1=go.Scatter(
            x = grouped_data['year'][grouped_data['top genre']==genre],
            y = grouped_data[attribute][grouped_data['top genre']==genre],
            name = attribute, visible = True)
            fig3.append_trace(trace1,1,1)
    trace2=go.Bar(
        x = data[data['top genre']==genre]['artist'].value_counts().index,
        y = list(data[data['top genre']==genre]['artist'].value_counts()),
        name = genre, visible = True
    )
    fig3.append_trace(trace2,2,1)
    
    
buttons = []
for i, genre in enumerate(genre_list):
    visibility = [i==j for j in range(len(genre_list))]
    print(visibility)
    button = dict(
                 label =  genre,
                 method = 'update',
                 args = [{'visible': visibility},
                     {'title': 'Trends By Genre'}])
    buttons.append(button)

updatemenus = list([
    dict(active=0,
         x=-0.15,
         buttons=buttons
    )
])
fig3['layout']['showlegend'] = True
fig3['layout']['updatemenus'] = updatemenus


# buttons = []


# for i, genre in enumerate(genre_list):
#     args = [False] * len(genre_list)
#     args[i] = True
#     print(args)
    
#     button = dict(label = genre,
#                   method = "update",
#                   args=[{"visible": args}])
    
#     buttons.append(button)
    
# fig3.update_layout(
#     updatemenus=[dict(
#                     active=0,
#                     type="dropdown",
#                     buttons=buttons,
#                     x = 0,
#                     y = 1.1,
#                     xanchor = 'left',
#                     yanchor = 'bottom'
#                 )], 
#     autosize=True,
#     title=dict(text='Artists with the most Top Songs (2010-2019)',
#                x=.5),
#     xaxis=dict(title='Artistr'),
#     yaxis=dict(title='Number of Songs'))

fig3.write_html('test3.html')



# =============================================================================
# Plotly Express attempt
# =============================================================================

grouped_data2=grouped_data[grouped_data['top genre'].isin(genre_list)]

longdf=pd.melt(grouped_data2,id_vars=['year','top genre'],value_vars=attributes)
longdf.sort_values(by=['top genre','year'],axis=0,inplace=True)
longdf = longdf.reset_index()

import plotly.express as px

fig4=px.line(longdf,x='year',y='value',animation_group='top genre',color='variable')
buttons=[]

for i, genre in enumerate(genre_list):
    args = [False] * len(genre_list)
    args[i] = True
    
    button = dict(label = genre,
                  method = "restyle",
                  args=[{"visible": args}])
    
    buttons.append(button)
    
fig4.update_layout(
    updatemenus=[dict(
                    active=0,
                    type="dropdown",
                    buttons=buttons,
                    x = 0,
                    y = 1.1,
                    xanchor = 'left',
                    yanchor = 'bottom'
                )], 
    autosize=True,
    title=dict(text='Attribute Trends by Genre',
               x=.5),
    xaxis=dict(title='Year'),
    yaxis=dict(title='Attribute Mean'))

fig4.write_html('test6.html')
